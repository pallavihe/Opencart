package testBase;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

public class BaseTest {

	public static WebDriver driver;
	public Logger logger;
	public Properties p;

	@BeforeClass(groups = { "Sanity", "Regression", "Master" })
	@Parameters({ "os", "browser" })
	public void setUp(String os, String br) throws IOException {

		// loading config properties file
		FileReader file = new FileReader("./src//main//resources//config.properties");
		p = new Properties();
		p.load(file);

		logger = LogManager.getLogger(this.getClass());

		if (p.getProperty("execution_env").equalsIgnoreCase("remote")) {

			DesiredCapabilities capabilites = new DesiredCapabilities();

			// os
			if (os.equalsIgnoreCase("windows")) {
				capabilites.setPlatform(Platform.WIN11);

			} else if (os.equalsIgnoreCase("MAC")) {

				capabilites.setPlatform(Platform.MAC);

			} else {
				System.out.println("No matching OS");
				return;

			}

			// browser
			switch (br.toLowerCase()) {
			case "chrome":
				capabilites.setBrowserName("chrome");
				break;
			case "edge":
				capabilites.setBrowserName("MicrosoftEdge");
				break;
			default:
				System.out.println("No matching browser");
				return;

			}
			driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilites);

		}

		if (p.getProperty("execution_env").equalsIgnoreCase("local")) {

			switch (br.toLowerCase()) {
			case "chrome":
				driver = new ChromeDriver();
				break;
			case "firefox":
				driver = new FirefoxDriver();
				break;
			default:
				System.out.println("Invalid browser name");
				return;
			}
		}

		// driver=new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		// driver.get("https://tutorialsninja.com/demo/");
		driver.get(p.getProperty("appurl"));
		driver.manage().window().maximize();
	}

	@AfterClass(groups = { "Sanity", "Regression", "Master" })
	public void tearDown() {
		driver.quit();

	}

	public String randomstring() {
		String generatedString = RandomStringUtils.randomAlphabetic(6);
		return generatedString;

	}

	public String randomNumber() {
		String generatedNumber = RandomStringUtils.randomNumeric(6);
		return generatedNumber;

	}

	public String randomAlphaNumeric() {
		String generatedString = RandomStringUtils.randomAlphabetic(6);
		String generatedNumber = RandomStringUtils.randomNumeric(6);

		// String GenaeratedAlphaNumeric="generatedString"+"@"+"generatedNumber";
		// return GenaeratedAlphaNumeric; OR
		return "generatedString" + "@" + "generatedNumber";

	}

	public String captureScreen(String tname) throws IOException {

		String timeStamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());

		TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);

		String targetFilePath = System.getProperty("user.dir") + "/screenshots/" + tname + "_" + timeStamp + ".png";

		File targetFile = new File(targetFilePath);

		// sourceFile.renameTo(targetFile);
		FileUtils.copyFile(sourceFile, targetFile);

		return targetFilePath;

	}
}
