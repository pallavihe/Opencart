package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {

	
	public HomePage(WebDriver driver) {
		super(driver);
	}

	// Locators

	@FindBy(xpath = "//span[normalize-space()='My Account']")
	WebElement txt_myAccount;

	@FindBy(xpath = "//a[normalize-space()='Register']")
	WebElement txt_Register;

	@FindBy(xpath = "//a[normalize-space()='Login']")
	WebElement txt_Login;

	// action

	public void clickMyaccount() {
		txt_myAccount.click();

	}

	public	void clickMyRegister() {
		txt_Register.click();

	}

	
	public	void clickMyLogin() {
		txt_Login.click();

	}
}
