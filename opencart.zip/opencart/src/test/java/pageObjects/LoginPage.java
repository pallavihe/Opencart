package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage{

	public LoginPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(xpath = "//input[@id='input-email']")
	WebElement txt_loginemail;
	
	@FindBy(xpath = "//input[@id='input-password']")
	WebElement txt_loginpassword;
	
	@FindBy(xpath = "//input[@value='Login']")
	WebElement clicklogin;
	
	
	public void setemail(String email) {
		txt_loginemail.sendKeys(email);
		
	}
	
	public void setpassword(String password) {
		txt_loginpassword.sendKeys(password);
		
	}
	
	public void clicklogin() {
		clicklogin.click();
		
	}
	

}
