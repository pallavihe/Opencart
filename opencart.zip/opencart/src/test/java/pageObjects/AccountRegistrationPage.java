package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountRegistrationPage extends BasePage{

	public AccountRegistrationPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "//input[@id='input-firstname']")
	WebElement txt_Firstname;

	@FindBy(xpath = "//input[@id='input-lastname']")
	WebElement txt_LastName;

	@FindBy(xpath = "//input[@id='input-email']")
	WebElement txt_email;

	@FindBy(xpath = "//input[@id='input-telephone']")
	WebElement txt_Telephone;

	@FindBy(xpath = "//input[@id='input-password']")
	WebElement txt_Password;

	@FindBy(xpath = "//input[@id='input-confirm']")
	WebElement txt_Confirm;

	@FindBy(xpath = "//input[@name='agree']")
	WebElement chk_agree;

	@FindBy(xpath = "//input[@value='Continue']")
	WebElement btn_Continue;
	
	
	@FindBy(xpath = "//h1[normalize-space()='Your Account Has Been Created!']")
	WebElement regconfirmationmessage;

	public void setFirstname(String fname) {
		txt_Firstname.sendKeys(fname);

	}

	public void setLastname(String lname) {
		txt_LastName.sendKeys(lname);

	}

	public void setEmail(String email) {
		txt_email.sendKeys(email);

	}

	public void settelephone(String telephone) {
		txt_Telephone.sendKeys(telephone);

	}

	public void setpassword(String password) {
		txt_Password.sendKeys(password);

	}

	public void setconfirm(String confirm) {
		txt_Confirm.sendKeys(confirm);

	}

	public void chkAgree() {
		chk_agree.click();

	}

	public void btnContinue() {
		btn_Continue.click();;

	}
	
	
	public String RegisterConfirmation() {
		try {
			return(regconfirmationmessage.getText());
			
		} catch (Exception e) {
		return(e.getMessage());
			// TODO: handle exception
		}
		
		
	}

}
