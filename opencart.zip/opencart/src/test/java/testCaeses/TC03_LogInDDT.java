package testCaeses;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseTest;
import utilities.DataProviders;

public class TC03_LogInDDT extends BaseTest {

	@Test(dataProvider = "LoginData", dataProviderClass = DataProviders.class,groups= {"Master","DataDriven"})
	public void verify_loginDDT(String email, String pwd, String exp) {
		try {
			HomePage hp = new HomePage(driver);
			hp.clickMyaccount();
			hp.clickMyLogin();

			LoginPage lp = new LoginPage(driver);
			lp.setemail(email);
			lp.setpassword(pwd);
			lp.clicklogin();

			MyAccountPage mp = new MyAccountPage(driver);
			boolean targetpage = mp.isMyAccountExist();

			/*
			 * Data is valid   - login success - test pass  - logout
			 *                 - login failed  - test fail
			 * Data is invalid - login success - test fail  - logout
			 *                 - login failed  - test pass
			 */

			if (exp.equalsIgnoreCase("Valid")) {
				if (targetpage) {
					mp.Clicklogout();
					Assert.assertTrue(true);
				} else {
					Assert.assertTrue(false, "Login failed for valid credentials");
				}
			} else if (exp.equalsIgnoreCase("Invalid")) {
				if (targetpage) {
					mp.Clicklogout();
					Assert.assertTrue(false, "Login passed for invalid credentials");
				} else {
					Assert.assertTrue(true);
				}
			}

		} catch (Exception e) {
			Assert.fail();
		}
	}
}
