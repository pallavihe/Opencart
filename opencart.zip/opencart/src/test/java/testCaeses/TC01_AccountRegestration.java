package testCaeses;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import pageObjects.AccountRegistrationPage;
import pageObjects.HomePage;
import testBase.BaseTest;

public class TC01_AccountRegestration extends BaseTest {

	@Test(groups= {"Sanity","Master"})
	public void Register() {

		logger.info("***** TC01_AccountRegestration execution started ********* ");

		try {
			HomePage hp = new HomePage(driver);

			hp.clickMyaccount();
			logger.info("***** Account page clicked ********* ");

			hp.clickMyRegister();

			AccountRegistrationPage Register = new AccountRegistrationPage(driver);

			logger.info("***** provided customer info ********* ");
			Register.setFirstname(randomstring());
			Register.setLastname(randomstring());
			Register.setEmail(randomstring() + "@gmail.com");
			Register.settelephone(randomNumber());

			String Password = randomAlphaNumeric();
			Register.setpassword(Password);
			Register.setconfirm(Password);
			Register.chkAgree();
			Register.btnContinue();

			String Title = Register.RegisterConfirmation();
			// Assert.assertEquals(Title, "Your Account Has Been Created!");

			if (Title.equals("Your Account Has Been Created!")) {
				AssertJUnit.assertTrue(true);

			} else {
				logger.error("Test Failed.....");
				logger.debug("Debug logs.....");
				AssertJUnit.assertTrue(false);

			}

			logger.info("***** register successfull ********* ");

		} catch (Exception e) {
			logger.info("***** TC01_AccountRegestration failed ********* ");
			logger.debug("logger.info");
			AssertJUnit.fail();

			// TODO: handle exception
		}
		logger.info("***** Finished TC01_AccountRegestration execution started ********* ");

	}
}
