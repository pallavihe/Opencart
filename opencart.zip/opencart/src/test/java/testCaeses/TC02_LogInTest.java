package testCaeses;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseTest;

public class TC02_LogInTest extends BaseTest {

	@Test(groups= {"Regression","Master"})
	public void VerifyLoginPage() {

		logger.info("***********TC02loginpage started***********");

		try {
			HomePage hp = new HomePage(driver);
			hp.clickMyaccount();
			hp.clickMyLogin();

			LoginPage lp = new LoginPage(driver);
			lp.setemail(p.getProperty("email"));
			lp.setpassword(p.getProperty("password"));
			lp.clicklogin();

			MyAccountPage mp = new MyAccountPage(driver);
			boolean targetpage = mp.isMyAccountExist();
			Assert.assertEquals(targetpage, true, "login failed");

		} catch (Exception e) {
			Assert.fail();
		}

		logger.info("***********TC02loginpage completed***********");

	}
}
